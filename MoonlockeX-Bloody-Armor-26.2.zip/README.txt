MOONLOCKEX ARMOR RESOURCE PACK
Minecraft Java 26.2 (resource pack format 88)

Includes the existing dark crimson Bloody Armor and the new blue/cyan Soulfire Armor.
Soulfire has four custom item models and a matching worn-armor equipment texture.
For server delivery, upload the ZIP and update server.properties resource-pack and SHA-1.
