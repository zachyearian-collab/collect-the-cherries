MOONLOCKEX BLOODY ARMOR RESOURCE PACK
Minecraft Java 26.2 (resource pack format 88)

This pack gives the custom Bloody Helmet, Chestplate, Leggings and Boots dark obsidian/crimson textures.
It changes only items using the MoonlockeX Bloody item model and equipment asset IDs.
Enable it in Options > Resource Packs. To share it with everyone on a server, host this ZIP at a direct-download URL and set server.properties resource-pack to that URL.
