MOONLOCKEX CUSTOM ARMOR RESOURCE PACK
Minecraft Java 26.2 (resource pack format 88)

Preserves the original Bloody Armor and Soulfire Armor files and adds 36 independently designed custom armor collections.
Every collection includes four inventory textures, four item model definitions, one equipment model definition, and three worn armor textures.

Each set uses /<armorname>kit give <player> or /<armorname>set give <player>.
Soulfire retains /soulkit and /soulset. The Soul armor collection uses /soularmorkit and /soularmorset.

The Warden set retains the approved dark-purple and cyan reference design exactly. The other 35 sets use individual theme-specific armor artwork, 4x high-resolution item and worn textures, layered plate seams, bevel highlights, recessed panel shading, hardware details, and distinct helmet, chestplate, leggings, and boots artwork. Their visual identity comes from custom textures and item models, not vanilla armor trims. Bloody Armor and Soulfire Armor files remain preserved exactly.
