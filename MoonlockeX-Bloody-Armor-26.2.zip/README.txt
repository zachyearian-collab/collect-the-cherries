MOONLOCKEX CUSTOM ARMOR RESOURCE PACK
Minecraft Java 26.2 (resource pack format 88)

Contains 36 custom armor collections, plus the existing Bloody Armor and Soulfire Armor sets.
Bloody Armor and Soulfire Armor textures, models, visuals, and gameplay requirements are preserved and are not overwritten.

TRUE 3D ARMOR
The 36 custom collections use separate 3D CEM wearable models for helmets, chestplates, leggings, and boots. The pack includes 144 model variants and 144 dedicated 256x128 material atlases. Each set has its own geometry and material design. Warden follows the approved dark-purple/black armor with cyan core, broad plated shoulders, full visor and segmented lower armor. The other 35 sets have distinct silhouettes, crowns, shoulders, cores, greaves, boots and theme-specific material details.

CLIENT REQUIREMENTS FOR 3D
Each player who wants to see the 3D armor must run Minecraft Java 26.2 on Fabric with:
- Entity Model Features 3.3.12 for Fabric 26.2
- Entity Texture Features 7.2.7 for Fabric 26.2
- MoonlockeX-Armor-CEM-26.2.jar
The server resource pack alone cannot install client mods. Without these client mods, players may see the base armor render rather than the custom 3D geometry.

ARMOR COMMANDS
Each set uses /<armorname>kit give <player> or /<armorname>set give <player>.
Soulfire retains /soulkit and /soulset. The Soul collection uses /soularmorkit and /soularmorset.

ECLIPSE
Standalone Eclipse Armor has been removed. Solar Eclipse Armor remains a separate set.

Bloody Armor and Soulfire Armor remain exactly as supplied. Their existing resource files are retained alongside the new 3D collections.
