MOONLOCKEX CUSTOM ARMOR RESOURCE PACK
Minecraft Java 26.2 (resource pack format 88)

Preserves the original Bloody Armor and Soulfire Armor files and adds 35 independently textured armor collections.
Every collection includes four inventory textures, four item model definitions, one equipment model definition, and three worn armor textures.

Each set uses /<armorname>kit give <player> or /<armorname>set give <player>.
Soulfire retains /soulkit and /soulset. The Soul armor collection uses /soularmorkit and /soularmorset.

All 35 added sets have individual color palettes and pixel-pattern accents. Existing Bloody and Soulfire texture files are preserved.
