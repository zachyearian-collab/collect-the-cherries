MOONLOCKEX BLOODY REALM — MINECRAFT 26.2

This is a per-player add-on pack. MoonlockeX automatically adds it while the wearer has all four authentic Bloody armor pieces equipped, and removes it when any piece is removed.

Visual changes: crimson sun and moon phases, bloody sky and clouds, red End sky, crimson water/underwater tint, red Gilded Blackstone, red pickaxes, a crimson Nether portal, and a red End portal shader.

The base MoonlockeX Bloody Armor pack remains required for everyone. This add-on is pushed only to full-set wearers.
