#version 330

#moj_import <minecraft:fog.glsl>

in float vertexDistance;
in vec4 vertexColor;
out vec4 fragColor;

void main() {
    float light = max(vertexColor.r, max(vertexColor.g, vertexColor.b));
    vec4 color = vec4(light * 0.92, light * 0.10, light * 0.15, vertexColor.a);
    color.a *= 1.0f - linear_fog_value(vertexDistance, 0, FogCloudsEnd);
    fragColor = color;
}
