#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
out vec4 fragColor;

void main() {
    float light = max(ColorModulator.r, max(ColorModulator.g, ColorModulator.b));
    vec3 bloodySky = vec3(light * 0.94, light * 0.12, light * 0.16);
    fragColor = apply_fog(vec4(bloodySky, ColorModulator.a), sphericalVertexDistance, cylindricalVertexDistance,
            0.0, FogSkyEnd, FogSkyEnd, FogSkyEnd, FogColor);
}
