MOONLOCKEX SOULFIRE ARMOR RESOURCE PACK
Minecraft Java 26.2 (resource pack format 88)

This standalone pack contains only the custom blue/cyan Soulfire Armor assets:
- Soulfire Helmet
- Soulfire Chestplate
- Soulfire Leggings
- Soulfire Boots
- Matching worn armor equipment textures

The full MoonlockeX server pack already includes these same Soulfire assets alongside Bloody Armor.
This standalone ZIP is provided for separate testing or manual installation.